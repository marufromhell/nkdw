I FUCKING HATE GITHUB ACTIONS



NK Declarative Wrapper  
Wraps around dnf so you can version control it!  
rhel based only, must be same rhel based distro ex: nobara->nobara/rhel8->rhel8                       
